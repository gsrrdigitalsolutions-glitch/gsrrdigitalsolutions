/* GSRR "Listen" panel — loaded only when the visitor first taps the Listen button.
   Uses the browser's built-in speech engine: no audio files are downloaded. */
(function () {
  var T = {
    en: {
      about: 'GSRR Digital Solutions is a digital marketing agency serving businesses in Hyderabad, Korutla, Jagtial and Karimnagar. We help local businesses get found online, reach more customers and grow, with clear and honest support.',
      services: 'We offer digital marketing, SEO, social media marketing, Google Ads, Google Business Profile optimisation, website development, poster designing and video editing. Every service is planned around one goal: more enquiries and more customers for your business.',
      training: 'Our Digital Marketing Training Program is designed for beginners, students, professionals and business owners. You will learn practical skills including SEO, social media marketing, Google Ads, Meta Ads, content creation and lead generation. The goal is to help you understand how businesses attract customers and grow online.',
      help: 'We help you in three simple steps. First, we understand your business and your customers. Then we plan and run your online marketing, such as search, social media and ads. Finally, we share clear reports, so you always know what is working.',
      contact: 'To get in touch, tap the WhatsApp button, or call 9618284932. You can also use the contact page to send an enquiry. Tell us about your business, or the training you need, and our team will reply to you.'
    },
    te: {
      about: 'జీఎస్ఆర్ఆర్ డిజిటల్ సొల్యూషన్స్ ఒక డిజిటల్ మార్కెటింగ్ సంస్థ. హైదరాబాద్, కోరుట్ల, జగిత్యాల, కరీంనగర్ ప్రాంతాల్లోని వ్యాపారాలు ఆన్‌లైన్‌లో కనిపించేలా, ఎక్కువ మంది కస్టమర్లను చేరుకునేలా మేము సహాయం చేస్తాం.',
      services: 'మేము డిజిటల్ మార్కెటింగ్, ఎస్ఈఓ, సోషల్ మీడియా మార్కెటింగ్, గూగుల్ యాడ్స్, గూగుల్ బిజినెస్ ప్రొఫైల్, వెబ్‌సైట్ డెవలప్‌మెంట్, పోస్టర్ డిజైనింగ్, వీడియో ఎడిటింగ్ సేవలు అందిస్తాం. మీ వ్యాపారానికి ఎక్కువ ఎంక్వైరీలు, ఎక్కువ కస్టమర్లు రావడమే మా లక్ష్యం.',
      training: 'మా డిజిటల్ మార్కెటింగ్ ట్రైనింగ్ ప్రోగ్రామ్ బిగినర్లు, విద్యార్థులు, ఉద్యోగులు మరియు వ్యాపారులందరికీ ఉపయోగపడేలా రూపొందించాం. ఇందులో ఎస్ఈఓ, సోషల్ మీడియా మార్కెటింగ్, గూగుల్ యాడ్స్, మెటా యాడ్స్, కంటెంట్ క్రియేషన్, లీడ్ జనరేషన్ వంటివి ప్రాక్టికల్‌గా నేర్చుకుంటారు. వ్యాపారాలు కస్టమర్లను ఎలా ఆకర్షిస్తాయో, ఆన్‌లైన్‌లో ఎలా ఎదుగుతాయో అర్థం చేసుకోవడమే ఈ కోర్సు లక్ష్యం.',
      help: 'మేము మీకు మూడు సులభమైన దశల్లో సహాయం చేస్తాం. మొదట మీ వ్యాపారాన్ని, మీ కస్టమర్లను అర్థం చేసుకుంటాం. తర్వాత సెర్చ్, సోషల్ మీడియా, యాడ్స్ ద్వారా ఆన్‌లైన్ మార్కెటింగ్ ప్లాన్ చేసి నడుపుతాం. చివరగా స్పష్టమైన రిపోర్ట్‌లు ఇస్తాం, కాబట్టి ఏది పని చేస్తుందో మీకు ఎప్పుడూ తెలుస్తుంది.',
      contact: 'మమ్మల్ని సంప్రదించడానికి వాట్సాప్ బటన్ నొక్కండి, లేదా 9618284932 నంబర్‌కు కాల్ చేయండి. కాంటాక్ట్ పేజీలో ఎంక్వైరీ కూడా పంపవచ్చు. మీ వ్యాపారం గురించి లేదా మీకు కావలసిన శిక్షణ గురించి చెప్పండి, మా బృందం మీకు సమాధానం ఇస్తుంది.'
    },
    hi: {
      about: 'जीएसआरआर डिजिटल सॉल्यूशंस एक डिजिटल मार्केटिंग एजेंसी है। हम हैदराबाद, कोरुटला, जगित्याल और करीमनगर के व्यवसायों को ऑनलाइन पहचान दिलाने, ज़्यादा ग्राहकों तक पहुँचने और आगे बढ़ने में मदद करते हैं।',
      services: 'हम डिजिटल मार्केटिंग, एसईओ, सोशल मीडिया मार्केटिंग, गूगल एड्स, गूगल बिज़नेस प्रोफ़ाइल, वेबसाइट डेवलपमेंट, पोस्टर डिज़ाइनिंग और वीडियो एडिटिंग की सेवाएँ देते हैं। हमारा लक्ष्य एक ही है: आपके बिज़नेस को ज़्यादा पूछताछ और ज़्यादा ग्राहक दिलाना।',
      training: 'हमारा डिजिटल मार्केटिंग ट्रेनिंग प्रोग्राम शुरुआत करने वालों, विद्यार्थियों, नौकरीपेशा लोगों और बिज़नेस मालिकों, सभी के लिए बनाया गया है। इसमें आप एसईओ, सोशल मीडिया मार्केटिंग, गूगल एड्स, मेटा एड्स, कंटेंट क्रिएशन और लीड जनरेशन जैसे काम व्यावहारिक रूप से सीखेंगे। हमारा मकसद है कि आप समझ सकें कि बिज़नेस ग्राहकों को कैसे आकर्षित करते हैं और ऑनलाइन कैसे बढ़ते हैं।',
      help: 'हम तीन आसान चरणों में आपकी मदद करते हैं। पहले हम आपके बिज़नेस और आपके ग्राहकों को समझते हैं। फिर सर्च, सोशल मीडिया और विज्ञापनों के ज़रिए आपकी ऑनलाइन मार्केटिंग की योजना बनाकर उसे चलाते हैं। आख़िर में हम साफ़ रिपोर्ट देते हैं, ताकि आपको हमेशा पता रहे कि क्या काम कर रहा है।',
      contact: 'हमसे जुड़ने के लिए व्हाट्सऐप बटन दबाइए, या 9618284932 पर कॉल कीजिए। आप कॉन्टैक्ट पेज पर पूछताछ भी भेज सकते हैं। हमें अपने बिज़नेस या अपनी ज़रूरत की ट्रेनिंग के बारे में बताइए, हमारी टीम आपको जवाब देगी।'
    }
  };
  var L = {
    en: { tag: 'en-IN', listen: 'Listen', stop: 'Stop', playing: 'Playing\u2026', nolang: '', unsupported: 'Audio is not supported in this browser. Please read the text below.', again: 'Tap Listen to start.',
          topics: { about: 'About GSRR', services: 'Our services', training: 'Training', help: 'How we help', contact: 'Contact us' } },
    te: { tag: 'te-IN', listen: 'వినండి', stop: 'ఆపండి', playing: 'వినిపిస్తోంది…', nolang: 'ఈ ఫోన్ లేదా బ్రౌజర్‌లో తెలుగు వాయిస్ లేకపోవచ్చు. అప్పుడు కింది టెక్స్ట్ చదవండి.', unsupported: 'ఈ బ్రౌజర్‌లో ఆడియో పనిచేయదు. దయచేసి కింది టెక్స్ట్ చదవండి.', again: 'మళ్లీ వినండి నొక్కండి.',
          topics: { about: 'మా గురించి', services: 'సేవలు', training: 'శిక్షణ', help: 'మేము ఎలా సహాయం చేస్తాం', contact: 'సంప్రదించండి' } },
    hi: { tag: 'hi-IN', listen: 'सुनें', stop: 'रुकें', playing: 'सुनाया जा रहा है…', nolang: 'इस फ़ोन या ब्राउज़र में हिंदी आवाज़ न हो तो नीचे दिया गया टेक्स्ट पढ़ें।', unsupported: 'इस ब्राउज़र में ऑडियो उपलब्ध नहीं है। कृपया नीचे का टेक्स्ट पढ़ें।', again: 'फिर से सुनें दबाएँ।',
          topics: { about: 'हमारे बारे में', services: 'सेवाएँ', training: 'ट्रेनिंग', help: 'हम कैसे मदद करते हैं', contact: 'संपर्क' } }
  };
  var synth = window.speechSynthesis, gen = 0;
  var fb = document.querySelector('.float-listen');
  var state = { lang: 'en', topic: document.body.getAttribute('data-voice-default') || 'about', playing: false };
  var TOPICS = ['about', 'services', 'training', 'help', 'contact'];

  var css = '.gl{position:fixed;z-index:130;right:18px;bottom:150px;width:min(380px,calc(100vw - 36px));background:#fff;color:#10151F;border:1px solid #E2DFD3;border-radius:14px;box-shadow:0 18px 44px -12px rgba(16,21,31,.45);font:15px/1.55 Manrope,-apple-system,"Segoe UI",sans-serif;outline:none;overflow:hidden;animation:glin .2s ease-out}' +
    '@keyframes glin{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}' +
    '.gl-h{display:flex;align-items:center;justify-content:space-between;background:#1A1A1A;color:#fff;padding:6px 6px 6px 18px;border-bottom:3px solid #C81E23}' +
    '.gl-h strong{font:600 1.05rem Newsreader,Georgia,serif}' +
    '.gl-x{width:44px;height:44px;border:0;background:none;color:#fff;font-size:26px;line-height:1;cursor:pointer;border-radius:8px}.gl-x:hover{background:rgba(255,255,255,.15)}' +
    '.gl-b{padding:14px 18px 18px}' +
    '.gl-r{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}' +
    '.gl-r button{min-height:44px;padding:8px 14px;border:1.5px solid #E2DFD3;border-radius:999px;background:#F7F6F1;color:#10151F;font:600 .9rem Manrope,-apple-system,"Segoe UI",sans-serif;cursor:pointer}' +
    '.gl-r button:hover{border-color:#1A1A1A}.gl-r button[aria-pressed=true]{background:#1A1A1A;border-color:#1A1A1A;color:#fff}' +
    '.gl-r--t button{min-height:40px;padding:6px 12px;font-size:.85rem}' +
    '.gl-p{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:48px;margin:4px 0 10px;border:0;border-radius:6px;background:#C81E23;color:#fff;font:700 1rem Manrope,-apple-system,"Segoe UI",sans-serif;cursor:pointer}.gl-p:hover{background:#9E161B}' +
    '.gl-s{min-height:1.2em;margin:0 0 8px;font-size:.85rem;color:#4A5163}' +
    '.gl-t{margin:0;max-height:34vh;overflow:auto;padding:12px 14px;background:#F7F6F1;border-left:3px solid #C81E23;border-radius:0 6px 6px 0;font-size:.95rem;line-height:1.7;color:#10151F}' +
    '.gl button:focus-visible{outline:3px solid #FF4B4F;outline-offset:2px}' +
    '@media(max-width:560px){.gl{left:0;right:0;bottom:0;width:100%;border-radius:14px 14px 0 0;max-height:88vh;overflow:auto}.gl-b{padding-bottom:calc(18px + env(safe-area-inset-bottom,0px))}.gl-t{max-height:28vh}}' +
    '@media(prefers-reduced-motion:reduce){.gl{animation:none}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var panel = null, els = {};

  function pickVoice(tag) {
    var vs = synth ? synth.getVoices() : [], base = tag.split('-')[0], i;
    for (i = 0; i < vs.length; i++) if (vs[i].lang.replace('_', '-').toLowerCase() === tag.toLowerCase()) return vs[i];
    for (i = 0; i < vs.length; i++) if (vs[i].lang.toLowerCase().indexOf(base) === 0) return vs[i];
    return null;
  }
  function el(tag, cls, attrs) { var e = document.createElement(tag); if (cls) e.className = cls; for (var k in attrs || {}) e.setAttribute(k, attrs[k]); return e; }

  function render() {
    var c = L[state.lang], k;
    els.langs.forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-lang') === state.lang)); });
    els.topics.forEach(function (b) {
      k = b.getAttribute('data-topic'); b.textContent = c.topics[k]; b.setAttribute('lang', state.lang);
      b.setAttribute('aria-pressed', String(k === state.topic));
    });
    els.play.textContent = state.playing ? '\u25A0  ' + c.stop : '\u25B6  ' + c.listen; els.play.setAttribute('lang', state.lang);
    els.text.setAttribute('lang', state.lang); els.text.textContent = T[state.lang][state.topic];
  }
  function setPlaying(on, msg) { state.playing = on; els.play.textContent = on ? '\u25A0  ' + L[state.lang].stop : '\u25B6  ' + L[state.lang].listen; els.status.textContent = msg || ''; }
  function stop() { gen++; if (synth) synth.cancel(); if (panel) setPlaying(false, ''); }

  function play() {
    var c = L[state.lang];
    if (!synth || typeof SpeechSynthesisUtterance === 'undefined') { els.status.textContent = c.unsupported; return; }
    synth.cancel(); var my = ++gen;
    var go = function () {
      if (my !== gen) return;
      var voice = pickVoice(c.tag), failed = false;
      var parts = T[state.lang][state.topic].replace(/\d{10}/g, function (m) { return m.split('').join(' '); }).match(/[^.\u0964!?]+[.\u0964!?]*/g) || [];
      var left = parts.length;
      parts.forEach(function (s) {
        var u = new SpeechSynthesisUtterance(s.trim()); u.lang = c.tag; u.rate = 0.95;
        if (voice) u.voice = voice;
        u.onend = function () { left--; if (left === 0 && my === gen) setPlaying(false, failed ? (c.nolang || c.again) : ''); };
        u.onerror = function (ev) { if (ev && (ev.error === 'canceled' || ev.error === 'interrupted')) return; failed = true; left--; if (left === 0 && my === gen) setPlaying(false, c.nolang || c.again); };
        synth.speak(u);
      });
      setPlaying(true, voice ? c.playing : (c.nolang || c.playing));
      setTimeout(function () { if (my === gen && state.playing && !synth.speaking && !synth.pending) setPlaying(false, c.nolang || c.again); }, 2000);
    };
    if (synth.getVoices().length) go();
    else { var done = false, run = function () { if (!done) { done = true; go(); } }; synth.addEventListener('voiceschanged', run, { once: true }); setTimeout(run, 600); }
  }

  function build() {
    panel = el('div', 'gl', { role: 'dialog', 'aria-label': 'Listen to GSRR Digital Solutions', tabindex: '-1' });
    var h = el('div', 'gl-h'); h.appendChild(el('strong')).textContent = 'Listen';
    var x = el('button', 'gl-x', { type: 'button', 'aria-label': 'Close' }); x.innerHTML = '&times;'; h.appendChild(x);
    var b = el('div', 'gl-b');
    var lr = el('div', 'gl-r', { role: 'group', 'aria-label': 'Language' });
    [['en', 'English'], ['te', '\u0C24\u0C46\u0C32\u0C41\u0C17\u0C41'], ['hi', '\u0939\u093F\u0902\u0926\u0940']].forEach(function (l) {
      var bt = el('button', '', { type: 'button', 'data-lang': l[0], 'aria-pressed': 'false' }); if (l[0] !== 'en') bt.setAttribute('lang', l[0]); bt.textContent = l[1]; lr.appendChild(bt);
    });
    var tr = el('div', 'gl-r gl-r--t', { role: 'group', 'aria-label': 'Topic' });
    TOPICS.forEach(function (k) { tr.appendChild(el('button', '', { type: 'button', 'data-topic': k, 'aria-pressed': 'false' })); });
    els.play = el('button', 'gl-p', { type: 'button' });
    els.status = el('p', 'gl-s', { role: 'status', 'aria-live': 'polite' });
    els.text = el('p', 'gl-t');
    [lr, tr, els.play, els.status, els.text].forEach(function (n) { b.appendChild(n); });
    panel.appendChild(h); panel.appendChild(b);
    els.langs = [].slice.call(lr.children); els.topics = [].slice.call(tr.children);
    panel.addEventListener('click', function (e) {
      var t = e.target.closest('button'); if (!t) return;
      if (t === x) { close(); return; }
      if (t.hasAttribute('data-lang')) { stop(); state.lang = t.getAttribute('data-lang'); render(); }
      else if (t.hasAttribute('data-topic')) { stop(); state.topic = t.getAttribute('data-topic'); render(); }
      else if (t === els.play) { state.playing ? stop() : play(); }
    });
    render();
  }
  function onKey(e) { if (e.key === 'Escape') close(); }
  function open() {
    if (panel && panel.parentNode) return;
    if (!panel) build();
    document.body.appendChild(panel); document.addEventListener('keydown', onKey);
    if (fb) fb.setAttribute('aria-expanded', 'true');
    try { panel.focus({ preventScroll: true }); } catch (e) { panel.focus(); }
  }
  function close() {
    stop(); document.removeEventListener('keydown', onKey);
    if (panel && panel.parentNode) panel.parentNode.removeChild(panel);
    if (fb) { fb.setAttribute('aria-expanded', 'false'); try { fb.focus({ preventScroll: true }); } catch (e) {} }
  }
  window.addEventListener('pagehide', function () { if (synth) synth.cancel(); });
  window.GSRRVoice = { toggle: function () { (panel && panel.parentNode) ? close() : open(); } };
  if (window.__gsrrVoiceOpen) { window.__gsrrVoiceOpen = false; open(); }
})();
