// GSRR Digital Solutions — shared site behaviour
document.addEventListener('DOMContentLoaded', function () {

  /* Mobile nav toggle (slide-in drawer + dimmed overlay, app-style) */
  var toggle = document.querySelector('.menu-toggle');
  var nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    var overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);

    var openNav = function () {
      nav.classList.add('open');
      overlay.classList.add('open');
      document.body.classList.add('nav-open');
      toggle.setAttribute('aria-expanded', 'true');
    };
    var closeNav = function () {
      nav.classList.remove('open');
      overlay.classList.remove('open');
      document.body.classList.remove('nav-open');
      toggle.setAttribute('aria-expanded', 'false');
    };

    toggle.addEventListener('click', function () {
      if (nav.classList.contains('open')) { closeNav(); } else { openNav(); }
    });
    overlay.addEventListener('click', closeNav);
    nav.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', closeNav);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && nav.classList.contains('open')) {
        closeNav();
        toggle.focus();
      }
    });
    /* If the viewport is resized past the mobile breakpoint while the
       drawer is open (e.g. rotating a tablet), reset it so it isn't stuck
       mid-transition on the desktop layout. */
    window.addEventListener('resize', function () {
      if (window.innerWidth > 960 && nav.classList.contains('open')) { closeNav(); }
    });
  }

  /* Footer year */
  document.querySelectorAll('.js-year').forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  /* Hero carousel — accessible, lazy, pausing */
  var carousel = document.querySelector('.carousel');
  if (carousel) {
    var slides = Array.prototype.slice.call(carousel.querySelectorAll('.carousel-slide'));
    var dotsWrap = carousel.querySelector('.carousel-dots');
    var idx = 0;
    var timer = null;

    slides.forEach(function (s, i) {
      if (dotsWrap) {
        var b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('aria-label', 'Show slide ' + (i + 1));
        if (i === 0) b.classList.add('active');
        b.addEventListener('click', function () { go(i); restart(); });
        dotsWrap.appendChild(b);
      }
    });
    var dots = dotsWrap ? Array.prototype.slice.call(dotsWrap.children) : [];

    function go(i) {
      slides[idx].classList.remove('active');
      if (dots[idx]) dots[idx].classList.remove('active');
      idx = (i + slides.length) % slides.length;
      slides[idx].classList.add('active');
      if (dots[idx]) dots[idx].classList.add('active');
    }

    function next() { go(idx + 1); }
    function prev() { go(idx - 1); }

    var prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function start() {
      if (prefersReduced) return;
      stop();
      timer = setInterval(next, 5500);
    }
    function stop() { if (timer) clearInterval(timer); timer = null; }
    function restart() { stop(); start(); }

    var nextBtn = carousel.querySelector('.carousel-arrow.next');
    var prevBtn = carousel.querySelector('.carousel-arrow.prev');
    if (nextBtn) nextBtn.addEventListener('click', function () { next(); restart(); });
    if (prevBtn) prevBtn.addEventListener('click', function () { prev(); restart(); });

    carousel.addEventListener('mouseenter', stop);
    carousel.addEventListener('mouseleave', start);
    carousel.addEventListener('focusin', stop);
    carousel.addEventListener('focusout', start);

    start();
  }

  /* Voice-over player (no autoplay, transcript toggle) */
  var voiceBtn = document.querySelector('.voice-btn');
  if (voiceBtn) {
    var audio = document.getElementById('gsrr-voiceover');
    var transcript = document.querySelector('.voice-transcript');
    voiceBtn.addEventListener('click', function () {
      if (!audio) {
        if (transcript) transcript.classList.toggle('show');
        return;
      }
      if (audio.paused) {
        audio.play();
        voiceBtn.textContent = '❚❚';
        voiceBtn.setAttribute('aria-label', 'Pause introduction');
      } else {
        audio.pause();
        voiceBtn.textContent = '►';
        voiceBtn.setAttribute('aria-label', 'Play introduction');
      }
    });
    if (audio) {
      audio.addEventListener('ended', function () {
        voiceBtn.textContent = '►';
      });
    }
  }

  /* Contact form — submits to Google Apps Script web app endpoint */
  var contactForm = document.getElementById('gsrr-contact-form');
  if (contactForm) {
    var endpoint = contactForm.getAttribute('data-endpoint');
    var statusEl = document.getElementById('gsrr-form-status');
    contactForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!endpoint) return;
      var submitBtn = contactForm.querySelector('button[type="submit"]');
      var formData = new FormData(contactForm);

      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Sending...'; }
      if (statusEl) { statusEl.textContent = 'Sending your enquiry…'; statusEl.style.color = 'var(--slate)'; }

      fetch(endpoint, {
        method: 'POST',
        mode: 'no-cors', // Apps Script web apps don't return CORS headers; response is opaque
        body: formData
      })
        .then(function () {
          if (statusEl) {
            statusEl.textContent = 'Thank you — your enquiry has been sent. We will get back to you shortly.';
            statusEl.style.color = 'var(--green-deep)';
          }
          contactForm.reset();
        })
        .catch(function () {
          if (statusEl) {
            statusEl.textContent = 'Something went wrong sending your enquiry. Please call or WhatsApp us instead.';
            statusEl.style.color = '#B3261E';
          }
        })
        .finally(function () {
          if (submitBtn) { submitBtn.disabled = false; submitBtn.textContent = 'Send Enquiry'; }
        });
    });
  }

  /* Active nav link highlighting */
  var path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.main-nav a').forEach(function (a) {
    var href = a.getAttribute('href');
    if (href === path || (path === '' && href === 'index.html')) {
      a.classList.add('current');
      a.setAttribute('aria-current', 'page');
    }
  });

  /* Script base path (works from / and /blog/) */
  var mainSrc = (document.querySelector('script[src*="assets/js/main.js"]') || {getAttribute:function(){return 'assets/js/main.js';}}).getAttribute('src');
  var base = mainSrc.replace(/assets\/js\/main\.js.*$/, '');
  window.GSRR_BASE = base;
  var V = '?v=20261005';
  function loadScript(name) {
    var s = document.createElement('script'); s.src = base + 'assets/js/' + name + V; s.async = true; document.head.appendChild(s);
  }

  /* Click-to-play YouTube: nothing from YouTube loads until the visitor presses play */
  document.querySelectorAll('.yt-facade').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var f = document.createElement('iframe');
      f.src = 'https://www.youtube-nocookie.com/embed/' + btn.getAttribute('data-yt') + '?autoplay=1&rel=0&modestbranding=1&playsinline=1';
      f.title = btn.getAttribute('data-title') || 'Video';
      f.allow = 'autoplay; encrypted-media; picture-in-picture'; f.allowFullscreen = true;
      f.referrerPolicy = 'strict-origin-when-cross-origin';
      btn.parentNode.replaceChild(f, btn); f.focus();
    });
  });

  /* Listen / AI voice: script loads on the first click inside the widget */
  var voiceWidgets = document.querySelectorAll('[data-voice]');
  if (voiceWidgets.length) {
    var voiceLoading = false;
    window.__gsrrVoiceQueue = [];
    voiceWidgets.forEach(function (w) {
      w.addEventListener('click', function (e) {
        if (window.GSRRVoice) return;
        var b = e.target.closest('button'); if (!b) return;
        window.__gsrrVoiceQueue.push(b);
        if (!voiceLoading) { voiceLoading = true; loadScript('voice.js'); }
      });
    });
  }

  /* Training popup: once per visitor (30 days), ~9s after load, never on the training page.
     The popup code is only downloaded at the moment it is shown. */
  (function () {
    var KEY = 'gsrrTrainingPopup', DAY = 864e5, WAIT = 30 * DAY;
    function seen() {
      try { var t = +localStorage.getItem(KEY); if (t) return Date.now() - t < WAIT; return false; } catch (e) {}
      return /(?:^|; )gsrrTrainingPopup=1/.test(document.cookie);
    }
    function mark() {
      try { localStorage.setItem(KEY, String(Date.now())); return true; } catch (e) {}
      document.cookie = KEY + '=1; max-age=2592000; path=/; SameSite=Lax';
      return /(?:^|; )gsrrTrainingPopup=1/.test(document.cookie);
    }
    if (document.body.hasAttribute('data-no-popup') || seen()) return;
    function show() {
      var a = document.activeElement;
      if ((a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName)) || document.body.classList.contains('nav-open') || seen()) return;
      if (!mark()) return; /* storage blocked: never risk showing it repeatedly */
      loadScript('popup.js');
    }
    function schedule() {
      setTimeout(function () {
        if (document.hidden) { document.addEventListener('visibilitychange', function h() { if (!document.hidden) { document.removeEventListener('visibilitychange', h); show(); } }); }
        else show();
      }, 9000);
    }
    if (document.readyState === 'complete') schedule(); else window.addEventListener('load', schedule);
  })();

});
