/* GSRR "Listen" feature — loaded only after the visitor first uses it.
   Uses the browser's built-in speech engine: no audio files are downloaded. */
(function () {
  var T = {
    en: {
      about: 'GSRR Digital Solutions is a digital marketing agency serving businesses in Hyderabad, Korutla, Jagtial and Karimnagar. We help local businesses get found online, reach more customers and grow, with clear and honest support.',
      services: 'We offer digital marketing, SEO, social media marketing, Google Ads, Google Business Profile optimisation, website development, poster designing and video editing. Every service is planned around one goal: more enquiries and more customers for your business.',
      training: 'Our Digital Marketing Training Program is designed for beginners, students, professionals and business owners. You will learn practical skills including SEO, social media marketing, Google Ads, Meta Ads, content creation and lead generation. The goal is to help you understand how businesses attract customers and grow online.',
      help: 'We help you in three simple steps. First, we understand your business and your customers. Then we plan and run your online marketing, such as search, social media and ads. Finally, we share clear reports, so you always know what is working.',
      contact: 'To get in touch, tap the WhatsApp button, or call 9618284932. You can also use the contact page to send an enquiry. Tell us about your business, or the training you need, and our team will reply to you.'
    },
    te: {
      about: 'జీఎస్ఆర్ఆర్ డిజిటల్ సొల్యూషన్స్ ఒక డిజిటల్ మార్కెటింగ్ సంస్థ. హైదరాబాద్, కోరుట్ల, జగిత్యాల, కరీంనగర్ ప్రాంతాల్లోని వ్యాపారాలు ఆన్‌లైన్‌లో కనిపించేలా, ఎక్కువ మంది కస్టమర్లను చేరుకునేలా మేము సహాయం చేస్తాం.',
      services: 'మేము డిజిటల్ మార్కెటింగ్, ఎస్ఈఓ, సోషల్ మీడియా మార్కెటింగ్, గూగుల్ యాడ్స్, గూగుల్ బిజినెస్ ప్రొఫైల్, వెబ్‌సైట్ డెవలప్‌మెంట్, పోస్టర్ డిజైనింగ్, వీడియో ఎడిటింగ్ సేవలు అందిస్తాం. మీ వ్యాపారానికి ఎక్కువ ఎంక్వైరీలు, ఎక్కువ కస్టమర్లు రావడమే మా లక్ష్యం.',
      training: 'మా డిజిటల్ మార్కెటింగ్ ట్రైనింగ్ ప్రోగ్రామ్ బిగినర్లు, విద్యార్థులు, ఉద్యోగులు మరియు వ్యాపారులందరికీ ఉపయోగపడేలా రూపొందించాం. ఇందులో ఎస్ఈఓ, సోషల్ మీడియా మార్కెటింగ్, గూగుల్ యాడ్స్, మెటా యాడ్స్, కంటెంట్ క్రియేషన్, లీడ్ జనరేషన్ వంటివి ప్రాక్టికల్‌గా నేర్చుకుంటారు. వ్యాపారాలు కస్టమర్లను ఎలా ఆకర్షిస్తాయో, ఆన్‌లైన్‌లో ఎలా ఎదుగుతాయో అర్థం చేసుకోవడమే ఈ కోర్సు లక్ష్యం.',
      help: 'మేము మీకు మూడు సులభమైన దశల్లో సహాయం చేస్తాం. మొదట మీ వ్యాపారాన్ని, మీ కస్టమర్లను అర్థం చేసుకుంటాం. తర్వాత సెర్చ్, సోషల్ మీడియా, యాడ్స్ ద్వారా ఆన్‌లైన్ మార్కెటింగ్ ప్లాన్ చేసి నడుపుతాం. చివరగా స్పష్టమైన రిపోర్ట్‌లు ఇస్తాం, కాబట్టి ఏది పని చేస్తుందో మీకు ఎప్పుడూ తెలుస్తుంది.',
      contact: 'మమ్మల్ని సంప్రదించడానికి వాట్సాప్ బటన్ నొక్కండి, లేదా 9618284932 నంబర్‌కు కాల్ చేయండి. కాంటాక్ట్ పేజీలో ఎంక్వైరీ కూడా పంపవచ్చు. మీ వ్యాపారం గురించి లేదా మీకు కావలసిన శిక్షణ గురించి చెప్పండి, మా బృందం మీకు సమాధానం ఇస్తుంది.'
    },
    hi: {
      about: 'जीएसआरआर डिजिटल सॉल्यूशंस एक डिजिटल मार्केटिंग एजेंसी है। हम हैदराबाद, कोरुटला, जगित्याल और करीमनगर के व्यवसायों को ऑनलाइन पहचान दिलाने, ज़्यादा ग्राहकों तक पहुँचने और आगे बढ़ने में मदद करते हैं।',
      services: 'हम डिजिटल मार्केटिंग, एसईओ, सोशल मीडिया मार्केटिंग, गूगल एड्स, गूगल बिज़नेस प्रोफ़ाइल, वेबसाइट डेवलपमेंट, पोस्टर डिज़ाइनिंग और वीडियो एडिटिंग की सेवाएँ देते हैं। हमारा लक्ष्य एक ही है: आपके बिज़नेस को ज़्यादा पूछताछ और ज़्यादा ग्राहक दिलाना।',
      training: 'हमारा डिजिटल मार्केटिंग ट्रेनिंग प्रोग्राम शुरुआत करने वालों, विद्यार्थियों, नौकरीपेशा लोगों और बिज़नेस मालिकों, सभी के लिए बनाया गया है। इसमें आप एसईओ, सोशल मीडिया मार्केटिंग, गूगल एड्स, मेटा एड्स, कंटेंट क्रिएशन और लीड जनरेशन जैसे काम व्यावहारिक रूप से सीखेंगे। हमारा मकसद है कि आप समझ सकें कि बिज़नेस ग्राहकों को कैसे आकर्षित करते हैं और ऑनलाइन कैसे बढ़ते हैं।',
      help: 'हम तीन आसान चरणों में आपकी मदद करते हैं। पहले हम आपके बिज़नेस और आपके ग्राहकों को समझते हैं। फिर सर्च, सोशल मीडिया और विज्ञापनों के ज़रिए आपकी ऑनलाइन मार्केटिंग की योजना बनाकर उसे चलाते हैं। आख़िर में हम साफ़ रिपोर्ट देते हैं, ताकि आपको हमेशा पता रहे कि क्या काम कर रहा है।',
      contact: 'हमसे जुड़ने के लिए व्हाट्सऐप बटन दबाइए, या 9618284932 पर कॉल कीजिए। आप कॉन्टैक्ट पेज पर पूछताछ भी भेज सकते हैं। हमें अपने बिज़नेस या अपनी ज़रूरत की ट्रेनिंग के बारे में बताइए, हमारी टीम आपको जवाब देगी।'
    }
  };
  var L = {
    en: { tag: 'en-IN', listen: 'Listen', stop: 'Stop', playing: 'Playing\u2026', nolang: '', unsupported: 'Audio is not supported in this browser. Please read the text below.', again: 'Tap Listen to start.',
          topics: { about: 'About GSRR', services: 'Our services', training: 'Training', help: 'How we help', contact: 'Contact us' } },
    te: { tag: 'te-IN', listen: 'వినండి', stop: 'ఆపండి', playing: 'వినిపిస్తోంది…', nolang: 'ఈ ఫోన్ లేదా బ్రౌజర్‌లో తెలుగు వాయిస్ లేకపోవచ్చు. అప్పుడు కింది టెక్స్ట్ చదవండి.', unsupported: 'ఈ బ్రౌజర్‌లో ఆడియో పనిచేయదు. దయచేసి కింది టెక్స్ట్ చదవండి.', again: 'మళ్లీ వినండి నొక్కండి.',
          topics: { about: 'మా గురించి', services: 'సేవలు', training: 'శిక్షణ', help: 'మేము ఎలా సహాయం చేస్తాం', contact: 'సంప్రదించండి' } },
    hi: { tag: 'hi-IN', listen: 'सुनें', stop: 'रुकें', playing: 'सुनाया जा रहा है…', nolang: 'इस फ़ोन या ब्राउज़र में हिंदी आवाज़ न हो तो नीचे दिया गया टेक्स्ट पढ़ें।', unsupported: 'इस ब्राउज़र में ऑडियो उपलब्ध नहीं है। कृपया नीचे का टेक्स्ट पढ़ें।', again: 'फिर से सुनें दबाएँ।',
          topics: { about: 'हमारे बारे में', services: 'सेवाएँ', training: 'ट्रेनिंग', help: 'हम कैसे मदद करते हैं', contact: 'संपर्क' } }
  };
  var synth = window.speechSynthesis;
  var gen = 0;

  function pickVoice(tag) {
    var vs = synth ? synth.getVoices() : [], base = tag.split('-')[0], i;
    for (i = 0; i < vs.length; i++) if (vs[i].lang.replace('_', '-').toLowerCase() === tag.toLowerCase()) return vs[i];
    for (i = 0; i < vs.length; i++) if (vs[i].lang.toLowerCase().indexOf(base) === 0) return vs[i];
    return null;
  }

  function Widget(el) {
    var self = this;
    self.el = el; self.lang = 'en'; self.topic = el.getAttribute('data-default') || 'training'; self.playing = false;
    self.playBtn = el.querySelector('.voice-play'); self.status = el.querySelector('.voice-status'); self.text = el.querySelector('.voice-text');
    el.addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) self.handle(b, false); });
    self.render();
  }
  Widget.prototype.handle = function (b, queued) {
    if (b.hasAttribute('data-lang')) { this.stop(); this.lang = b.getAttribute('data-lang'); this.render(); }
    else if (b.hasAttribute('data-topic')) { this.stop(); this.topic = b.getAttribute('data-topic'); this.render(); }
    else if (b.classList.contains('voice-play')) { this.playing ? this.stop() : this.play(); }
  };
  Widget.prototype.render = function () {
    var self = this, c = L[self.lang];
    self.el.querySelectorAll('[data-lang]').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-lang') === self.lang)); });
    self.el.querySelectorAll('[data-topic]').forEach(function (b) {
      var k = b.getAttribute('data-topic'); b.textContent = c.topics[k]; b.setAttribute('lang', self.lang);
      b.setAttribute('aria-pressed', String(k === self.topic));
    });
    self.playBtn.textContent = self.playing ? c.stop : c.listen; self.playBtn.setAttribute('lang', self.lang);
    self.text.hidden = false; self.text.setAttribute('lang', self.lang); self.text.textContent = T[self.lang][self.topic];
    self.status.textContent = '';
  };
  Widget.prototype.setPlaying = function (on, msg) {
    this.playing = on; this.playBtn.textContent = on ? L[this.lang].stop : L[this.lang].listen;
    this.status.textContent = msg || '';
  };
  Widget.prototype.stop = function () { gen++; if (synth) synth.cancel(); this.setPlaying(false, ''); };
  Widget.prototype.play = function () {
    var self = this, c = L[self.lang];
    if (!synth || typeof SpeechSynthesisUtterance === 'undefined') { self.status.textContent = c.unsupported; return; }
    synth.cancel(); var my = ++gen;
    var go = function () {
      if (my !== gen) return;
      var voice = pickVoice(c.tag);
      var parts = T[self.lang][self.topic].replace(/\d{10}/g, function (m) { return m.split('').join(' '); }).match(/[^.।!?]+[.।!?]*/g) || [];
      var left = parts.length, failed = false;
      parts.forEach(function (s, i) {
        var u = new SpeechSynthesisUtterance(s.trim()); u.lang = c.tag; u.rate = 0.95;
        if (voice) u.voice = voice;
        u.onend = function () { left--; if (left === 0 && my === gen) self.setPlaying(false, failed ? (c.nolang || c.again) : ''); };
        u.onerror = function (ev) { if (ev && (ev.error === 'canceled' || ev.error === 'interrupted')) return; failed = true; left--; if (left === 0 && my === gen) self.setPlaying(false, c.nolang || c.again); };
        synth.speak(u);
      });
      self.setPlaying(true, voice ? c.playing : (c.nolang || c.playing));
      setTimeout(function () { if (my === gen && self.playing && !synth.speaking && !synth.pending) self.setPlaying(false, c.nolang || c.again); }, 2000);
    };
    if (synth.getVoices().length) go(); else { var done = false; var run = function () { if (!done) { done = true; go(); } }; synth.addEventListener('voiceschanged', run, { once: true }); setTimeout(run, 600); }
  };

  var widgets = [];
  document.querySelectorAll('[data-voice]').forEach(function (el) { widgets.push(new Widget(el)); });
  window.addEventListener('pagehide', function () { if (synth) synth.cancel(); });
  window.GSRRVoice = { ready: true };

  /* replay clicks made while this file was loading (first click on a language/topic) */
  (window.__gsrrVoiceQueue || []).forEach(function (b) {
    widgets.forEach(function (w) { if (w.el.contains(b)) w.handle(b, true); });
  });
  window.__gsrrVoiceQueue = [];
})();
