/* GSRR training popup — loaded on demand by main.js, ~9s after page load, once per visitor. */
(function () {
  var B = window.GSRR_BASE || '';
  var WA = 'https://wa.me/919618284932?text=' + encodeURIComponent('Hello GSRR Digital Solutions, I am interested in your Digital Marketing Training Program. Please share the course details, fees and timings.');
  var css = '.gp{position:fixed;z-index:120;left:20px;bottom:20px;width:min(400px,calc(100vw - 40px));background:#fff;color:#10151F;border:1px solid #E2DFD3;border-top:4px solid #C81E23;border-radius:14px;box-shadow:0 18px 44px -12px rgba(16,21,31,.45);padding:22px 22px 20px;font:15px/1.55 Manrope,-apple-system,"Segoe UI",sans-serif;outline:none;animation:gpin .25s ease-out}' +
    '@keyframes gpin{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}' +
    '.gp h2{font:600 1.25rem/1.25 Newsreader,Georgia,serif;margin:0 28px 8px 0;color:#1A1A1A}' +
    '.gp p{margin:0 0 14px;color:#4A5163}' +
    '.gp-x{position:absolute;top:6px;right:6px;width:44px;height:44px;border:0;background:none;font-size:26px;line-height:1;color:#4A5163;cursor:pointer;border-radius:8px}' +
    '.gp-x:hover{background:#EFEDE4}' +
    '.gp-b{display:flex;flex-direction:column;gap:8px}' +
    '.gp-b a{display:flex;align-items:center;justify-content:center;min-height:44px;padding:10px 16px;border-radius:6px;font-weight:600;text-decoration:none;border:1.5px solid #1A1A1A;color:#1A1A1A}' +
    '.gp-b a:hover{background:#1A1A1A;color:#fff}' +
    '.gp-b .gp-wa{background:#117A43;border-color:#117A43;color:#fff}.gp-b .gp-wa:hover{background:#0D6537;border-color:#0D6537}' +
    '.gp a:focus-visible,.gp button:focus-visible{outline:3px solid #FF4B4F;outline-offset:2px}' +
    '@media(max-width:560px){.gp{left:0;right:0;bottom:0;width:100%;border-radius:14px 14px 0 0;padding-bottom:calc(20px + env(safe-area-inset-bottom,0px));max-height:85vh;overflow:auto}}' +
    '@media(prefers-reduced-motion:reduce){.gp{animation:none}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  var d = document.createElement('div');
  d.className = 'gp'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-labelledby', 'gp-t'); d.tabIndex = -1;
  d.innerHTML = '<button type="button" class="gp-x" aria-label="Close training offer">&times;</button>' +
    '<h2 id="gp-t">\uD83D\uDE80 Digital Marketing Training \u2013 Learn. Practice. Grow.</h2>' +
    '<p>Want to learn Digital Marketing, SEO, Social Media Marketing, Google Ads, Meta Ads, Content Creation and Lead Generation? Join our practical training program and learn how businesses actually grow online.</p>' +
    '<div class="gp-b">' +
    '<a class="gp-wa" href="' + WA + '" target="_blank" rel="noopener noreferrer">\uD83D\uDCF2 Contact on WhatsApp</a>' +
    '<a href="' + B + 'contact.html">\uD83D\uDCDE Contact Us</a>' +
    '<a href="' + B + 'training.html">Learn More</a></div>';
  document.body.appendChild(d);

  var prev = document.activeElement;
  function close() {
    document.removeEventListener('keydown', onKey);
    if (d.parentNode) d.parentNode.removeChild(d);
    if (prev && document.contains(prev) && prev !== document.body) { try { prev.focus({ preventScroll: true }); } catch (e) {} }
  }
  function onKey(e) { if (e.key === 'Escape') close(); }
  d.querySelector('.gp-x').addEventListener('click', close);
  d.querySelectorAll('.gp-b a').forEach(function (a) { a.addEventListener('click', function () { if (a.target === '_blank') close(); }); });
  document.addEventListener('keydown', onKey);
  try { d.focus({ preventScroll: true }); } catch (e) { d.focus(); }
})();
